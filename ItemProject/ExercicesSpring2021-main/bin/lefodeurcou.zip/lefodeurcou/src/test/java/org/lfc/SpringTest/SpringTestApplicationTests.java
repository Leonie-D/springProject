package org.lfc.SpringTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
